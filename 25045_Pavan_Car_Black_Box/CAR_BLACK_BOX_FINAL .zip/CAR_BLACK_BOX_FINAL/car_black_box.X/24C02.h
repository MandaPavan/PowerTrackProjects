#ifndef EEPROM_24C02_DEVICE_H
#define EEPROM_24C02_DEVICE_H

/*
 * 24C02 external EEPROM device declarations are provided in EEprom.h.
 * Project : Car Black Box
 * Author  : MANDA PAVAN KALYAN
 * Date    : 27/06/2026
 */

#endif /* EEPROM_24C02_DEVICE_H */
