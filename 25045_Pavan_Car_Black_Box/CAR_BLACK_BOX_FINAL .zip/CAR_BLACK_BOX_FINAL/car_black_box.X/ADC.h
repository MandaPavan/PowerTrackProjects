#ifndef ADC_H
#define ADC_H

#ifndef _XTAL_FREQ
#define _XTAL_FREQ 20000000UL
#endif

void init_adc(void);
unsigned short read_adc(void);

#endif /* ADC_H */
