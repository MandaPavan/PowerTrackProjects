/*
 * Project : Car Black Box
 * Author  : MANDA PAVAN KALYAN
 * Date    : 27/06/2026
 */

#include <xc.h>
#include "EEprom.h"
#include "I2C.h"

#ifndef _XTAL_FREQ
#define _XTAL_FREQ 20000000UL
#endif

#define EEPROM_ACK_RETRIES 100U

static void wait_for_write_complete(void)
{
    unsigned char retry;
    unsigned char acknowledged;

    for (retry = 0U; retry < EEPROM_ACK_RETRIES; retry++)
    {
        i2c_start();
        acknowledged = (unsigned char)i2c_write(SLAVE_WRITE_EEPROM);
        i2c_stop();

        if (acknowledged)
        {
            return;
        }

        __delay_us(100);
    }
}

unsigned char ext_eeprom_24C02_read(unsigned char address)
{
    unsigned char data;

    i2c_start();
    i2c_write(SLAVE_WRITE_EEPROM);
    i2c_write(address);
    i2c_rep_start();
    i2c_write(SLAVE_READ_EEPROM);
    data = i2c_read(0U); /* NACK after the only byte. */
    i2c_stop();

    return data;
}

void ext_eeprom_24C02_byte_write(unsigned char address, unsigned char data)
{
    i2c_start();
    i2c_write(SLAVE_WRITE_EEPROM);
    i2c_write(address);
    i2c_write(data);
    i2c_stop();

    wait_for_write_complete();
}

void ext_eeprom_24C02_block_write(unsigned char address,
                                  const unsigned char *data,
                                  unsigned char length)
{
    unsigned char index;

    for (index = 0U; index < length; index++)
    {
        ext_eeprom_24C02_byte_write((unsigned char)(address + index),
                                    data[index]);
    }
}

void ext_eeprom_24C02_str_write(unsigned char address, const char *data)
{
    while (*data != '\0')
    {
        ext_eeprom_24C02_byte_write(address, (unsigned char)*data);
        address++;
        data++;
    }
}
