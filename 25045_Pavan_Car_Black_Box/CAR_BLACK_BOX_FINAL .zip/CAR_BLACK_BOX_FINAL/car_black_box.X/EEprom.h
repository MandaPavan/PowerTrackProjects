#ifndef EEPROM_H
#define EEPROM_H

#define SLAVE_WRITE_EEPROM  0xA0U
#define SLAVE_READ_EEPROM   0xA1U

unsigned char ext_eeprom_24C02_read(unsigned char address);
void ext_eeprom_24C02_byte_write(unsigned char address, unsigned char data);
void ext_eeprom_24C02_block_write(unsigned char address,
                                  const unsigned char *data,
                                  unsigned char length);
void ext_eeprom_24C02_str_write(unsigned char address, const char *data);

#endif /* EEPROM_H */
