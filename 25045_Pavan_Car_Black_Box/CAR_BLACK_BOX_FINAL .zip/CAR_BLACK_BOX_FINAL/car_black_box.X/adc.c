#include <xc.h>
#include "ADC.h"

void init_adc(void)
{
    /*
     * PICGenios shares PORTD between the CLCD data bus and the four
     * seven-segment displays. RA2..RA5 are the active-high digit selects.
     * Keep every SSD digit disabled so CLCD writes cannot appear on DISP1-4.
     */
    ADCON1 = 0x8EU; /* AN0 analogue; remaining analogue-capable pins digital. */
    PORTA = 0x00U;  /* Preload RA2..RA5 output latches low. */
    TRISA = 0x03U;  /* RA0/RA1 inputs; RA2..RA5 outputs, all SSDs disabled. */
    ADCON0 = 0x81U; /* AN0, Fosc/32, ADC enabled. */
}

unsigned short read_adc(void)
{
    unsigned short result;

    __delay_us(20);
    GO = 1;
    while (nDONE)
    {
        ;
    }

    result = (unsigned short)(((unsigned short)ADRESH << 8) | ADRESL);
    return result;
}
