#include <xc.h>
#include "clcd.h"

static void pulse_enable(void)
{
    CLCD_EN = HI;
    __delay_us(1);
    CLCD_EN = LOW;
}

void clcd_write(unsigned char byte, unsigned char mode)
{
    CLCD_RS = mode;

    CLCD_DATA_PORT = (unsigned char)(byte & 0xF0U);
    pulse_enable();

    CLCD_DATA_PORT = (unsigned char)((byte & 0x0FU) << 4);
    pulse_enable();

    if ((mode == INST_MODE) &&
        ((byte == CLEAR_DISP_SCREEN) || (byte == 0x02U)))
    {
        __delay_ms(2);
    }
    else
    {
        __delay_us(50);
    }
}

static void init_display_controller(void)
{
    __delay_ms(30);

    clcd_write(EIGHT_BIT_MODE, INST_MODE);
    __delay_ms(5);
    clcd_write(EIGHT_BIT_MODE, INST_MODE);
    __delay_us(150);
    clcd_write(EIGHT_BIT_MODE, INST_MODE);
    clcd_write(FOUR_BIT_MODE, INST_MODE);
    clcd_write(TWO_LINES_5x8_4_BIT_MODE, INST_MODE);
    clcd_write(CLEAR_DISP_SCREEN, INST_MODE);
    clcd_write(DISP_ON_AND_CURSOR_OFF, INST_MODE);
}

void init_clcd(void)
{
    CLCD_DATA_PORT_DDR = 0x00U;
    CLCD_RS_DDR = 0;
    CLCD_EN_DDR = 0;
    init_display_controller();
}

void clcd_putch(const char data, unsigned char address)
{
    clcd_write(address, INST_MODE);
    clcd_write((unsigned char)data, DATA_MODE);
}

void clcd_print(const char *string, unsigned char address)
{
    clcd_write(address, INST_MODE);

    while (*string != '\0')
    {
        clcd_write((unsigned char)*string, DATA_MODE);
        string++;
    }
}
