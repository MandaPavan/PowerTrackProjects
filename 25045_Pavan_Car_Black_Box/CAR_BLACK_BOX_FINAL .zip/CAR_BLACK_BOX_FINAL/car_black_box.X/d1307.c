#include <xc.h>
#include "ds1307.h"
#include "I2C.h"

void init_ds1307(void)
{
    unsigned char seconds;
    unsigned char hours;
    unsigned char hour_value;

    /* Clear the CH bit so the oscillator runs. */
    seconds = (unsigned char)(read_ds1307(SEC_ADDR) & 0x7FU);
    write_ds1307(SEC_ADDR, seconds);

    /* The project uses 00-23, so convert a 12-hour RTC setting if needed. */
    hours = read_ds1307(HOUR_ADDR);
    if (hours & 0x40U)
    {
        hour_value = (unsigned char)((((hours >> 4) & 0x01U) * 10U) +
                                     (hours & 0x0FU));

        if (hours & 0x20U)
        {
            if (hour_value != 12U)
            {
                hour_value = (unsigned char)(hour_value + 12U);
            }
        }
        else if (hour_value == 12U)
        {
            hour_value = 0U;
        }

        write_ds1307(HOUR_ADDR,
                     (unsigned char)(((hour_value / 10U) << 4) |
                                      (hour_value % 10U)));
    }
}

unsigned char read_ds1307(unsigned char address)
{
    unsigned char data;

    i2c_start();
    i2c_write(SLAVE_WRITE);
    i2c_write(address);
    i2c_rep_start();
    i2c_write(SLAVE_READ);
    data = i2c_read(0U); /* NACK after the only byte. */
    i2c_stop();

    return data;
}

void write_ds1307(unsigned char address, unsigned char data)
{
    i2c_start();
    i2c_write(SLAVE_WRITE);
    i2c_write(address);
    i2c_write(data);
    i2c_stop();
}
