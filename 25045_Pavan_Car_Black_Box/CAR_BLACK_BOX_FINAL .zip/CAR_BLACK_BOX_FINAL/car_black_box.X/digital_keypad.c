/*
 * Short-press keypad driver.
 * One event is returned only on a stable released-to-pressed edge.
 * Holding a switch never repeats the event; another event requires release.
 *
 * Author : MANDA PAVAN KALYAN
 * Date   : 27/06/2026
 */

#include <xc.h>
#include "digital_keypad.h"

#ifndef _XTAL_FREQ
#define _XTAL_FREQ 20000000UL
#endif

#define DEBOUNCE_TIME_MS 20U

static unsigned char is_single_valid_key(unsigned char key)
{
    return (unsigned char)((key == SW1) || (key == SW2) ||
                           (key == SW3) || (key == SW4) ||
                           (key == SW5) || (key == SW6));
}

void init_digital_keypad(void)
{
    KEYPAD_PORT_DDR |= INPUT_LINES;
}

unsigned char read_digital_keypad(void)
{
    static unsigned char stable_state = ALL_RELEASED;
    unsigned char raw_state;
    unsigned char confirmed_state;
    unsigned char previous_state;

    raw_state = (unsigned char)(KEYPAD_PORT & INPUT_LINES);

    if (raw_state == stable_state)
    {
        return ALL_RELEASED;
    }

    __delay_ms(DEBOUNCE_TIME_MS);
    confirmed_state = (unsigned char)(KEYPAD_PORT & INPUT_LINES);

    if (confirmed_state != raw_state)
    {
        return ALL_RELEASED;
    }

    previous_state = stable_state;
    stable_state = confirmed_state;

    if ((previous_state == ALL_RELEASED) &&
        is_single_valid_key(stable_state))
    {
        return stable_state;
    }

    return ALL_RELEASED;
}
