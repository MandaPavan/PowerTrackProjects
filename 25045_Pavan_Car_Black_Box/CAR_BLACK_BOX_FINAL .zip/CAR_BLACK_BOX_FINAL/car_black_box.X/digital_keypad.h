#ifndef DIGITAL_KEYPAD_H
#define DIGITAL_KEYPAD_H

#define KEYPAD_PORT       PORTB
#define KEYPAD_PORT_DDR   TRISB
#define INPUT_LINES       0x3FU

#define SW1               0x3EU
#define SW2               0x3DU
#define SW3               0x3BU
#define SW4               0x37U
#define SW5               0x2FU
#define SW6               0x1FU
#define ALL_RELEASED      INPUT_LINES

void init_digital_keypad(void);
unsigned char read_digital_keypad(void);

#endif /* DIGITAL_KEYPAD_H */
