/*
 * Project : Car Black Box
 * Author  : MANDA PAVAN KALYAN
 * Date    : 27/06/2026
 */

#include "main.h"

#define MAX_LOGS                    10U
#define LOG_RECORD_SIZE             10U
#define LOG_START_ADDR              0x00U

#define PASSWORD_ADDR               0xE0U
#define PASSWORD_MAGIC_ADDR         0xE4U
#define PASSWORD_MAGIC              0xA5U

#define LOG_META_MAGIC_ADDR         0xF0U
#define LOG_META_WRITE_INDEX_ADDR   0xF1U
#define LOG_META_COUNT_ADDR         0xF2U
#define LOG_META_MAGIC              0x5AU

unsigned char clock_reg[3];
char time[7];

extern volatile unsigned char sec;
extern volatile unsigned char half_second_tick;

static unsigned char log_write_index;
static unsigned char log_count;

static const char * const menu[5] =
{
    "View log",
    "Clear log",
    "Download log",
    "Set time",
    "Change password"
};

static void delay_ms(unsigned int milliseconds)
{
    while (milliseconds > 0U)
    {
        __delay_ms(1);
        milliseconds--;
    }
}

static void clear_line(unsigned char line_address)
{
    clcd_print("                ", line_address);
}

static void write_log_metadata(void)
{
    ext_eeprom_24C02_byte_write(LOG_META_WRITE_INDEX_ADDR, log_write_index);
    ext_eeprom_24C02_byte_write(LOG_META_COUNT_ADDR, log_count);
    ext_eeprom_24C02_byte_write(LOG_META_MAGIC_ADDR, LOG_META_MAGIC);
}

static void initialize_password(void)
{
    unsigned char valid = 1U;
    unsigned char index;
    unsigned char value;

    if (ext_eeprom_24C02_read(PASSWORD_MAGIC_ADDR) != PASSWORD_MAGIC)
    {
        valid = 0U;
    }

    for (index = 0U; index < 4U; index++)
    {
        value = ext_eeprom_24C02_read((unsigned char)(PASSWORD_ADDR + index));
        if ((value != '0') && (value != '1'))
        {
            valid = 0U;
        }
    }

    if (!valid)
    {
        ext_eeprom_24C02_byte_write(PASSWORD_ADDR + 0U, '1');
        ext_eeprom_24C02_byte_write(PASSWORD_ADDR + 1U, '1');
        ext_eeprom_24C02_byte_write(PASSWORD_ADDR + 2U, '1');
        ext_eeprom_24C02_byte_write(PASSWORD_ADDR + 3U, '0');
        ext_eeprom_24C02_byte_write(PASSWORD_MAGIC_ADDR, PASSWORD_MAGIC);
    }
}

void storage_init(void)
{
    initialize_password();

    if (ext_eeprom_24C02_read(LOG_META_MAGIC_ADDR) == LOG_META_MAGIC)
    {
        log_write_index = ext_eeprom_24C02_read(LOG_META_WRITE_INDEX_ADDR);
        log_count = ext_eeprom_24C02_read(LOG_META_COUNT_ADDR);

        if ((log_write_index >= MAX_LOGS) || (log_count > MAX_LOGS))
        {
            log_write_index = 0U;
            log_count = 0U;
            write_log_metadata();
        }
    }
    else
    {
        log_write_index = 0U;
        log_count = 0U;
        write_log_metadata();
    }
}

void get_time(void)
{
    clock_reg[0] = read_ds1307(HOUR_ADDR);
    clock_reg[1] = read_ds1307(MIN_ADDR);
    clock_reg[2] = read_ds1307(SEC_ADDR);

    time[0] = (char)(((clock_reg[0] >> 4) & 0x03U) + '0');
    time[1] = (char)((clock_reg[0] & 0x0FU) + '0');
    time[2] = (char)(((clock_reg[1] >> 4) & 0x07U) + '0');
    time[3] = (char)((clock_reg[1] & 0x0FU) + '0');
    time[4] = (char)(((clock_reg[2] >> 4) & 0x07U) + '0');
    time[5] = (char)((clock_reg[2] & 0x0FU) + '0');
    time[6] = '\0';
}

void display_time(void)
{
    get_time();

    clcd_putch(time[0], LINE2(2));
    clcd_putch(time[1], LINE2(3));
    clcd_putch(':', LINE2(4));
    clcd_putch(time[2], LINE2(5));
    clcd_putch(time[3], LINE2(6));
    clcd_putch(':', LINE2(7));
    clcd_putch(time[4], LINE2(8));
    clcd_putch(time[5], LINE2(9));
}

void display_dash_board(const char event[], unsigned char speed)
{
    clcd_print("  TIME     EV SP", LINE1(0));
    display_time();
    clcd_putch(event[0], LINE2(11));
    clcd_putch(event[1], LINE2(12));
    clcd_putch((char)((speed / 10U) + '0'), LINE2(14));
    clcd_putch((char)((speed % 10U) + '0'), LINE2(15));
}

static void write_log_record(const char record[LOG_RECORD_SIZE])
{
    unsigned char address;

    address = (unsigned char)(LOG_START_ADDR +
              (log_write_index * LOG_RECORD_SIZE));

    ext_eeprom_24C02_block_write(address,
                                  (const unsigned char *)record,
                                  LOG_RECORD_SIZE);

    log_write_index++;
    if (log_write_index >= MAX_LOGS)
    {
        log_write_index = 0U;
    }

    if (log_count < MAX_LOGS)
    {
        log_count++;
    }

    write_log_metadata();
}

void log_car_event(const char *event, unsigned char speed)
{
    char record[LOG_RECORD_SIZE];

    get_time();

    record[0] = time[0];
    record[1] = time[1];
    record[2] = time[2];
    record[3] = time[3];
    record[4] = time[4];
    record[5] = time[5];
    record[6] = event[0];
    record[7] = event[1];
    record[8] = (char)((speed / 10U) + '0');
    record[9] = (char)((speed % 10U) + '0');

    write_log_record(record);
}

static unsigned char oldest_log_index(void)
{
    if (log_count < MAX_LOGS)
    {
        return 0U;
    }

    return log_write_index;
}

static void read_log_record(unsigned char order, char record[LOG_RECORD_SIZE])
{
    unsigned char physical_index;
    unsigned char address;
    unsigned char index;

    physical_index = (unsigned char)((oldest_log_index() + order) % MAX_LOGS);
    address = (unsigned char)(LOG_START_ADDR +
              (physical_index * LOG_RECORD_SIZE));

    for (index = 0U; index < LOG_RECORD_SIZE; index++)
    {
        record[index] = (char)ext_eeprom_24C02_read((unsigned char)(address + index));
    }
}

void get_password(char *password)
{
    unsigned char index;

    for (index = 0U; index < 4U; index++)
    {
        password[index] = (char)ext_eeprom_24C02_read(
                                      (unsigned char)(PASSWORD_ADDR + index));
    }
    password[4] = '\0';
}

static void show_login_prompt(void)
{
    clcd_write(CLEAR_DISP_SCREEN, INST_MODE);
    clcd_print("Enter password", LINE1(1));
    clear_line(LINE2(0));
    clcd_write(DISP_ON_AND_CURSOR_ON, INST_MODE);
    clcd_write(LINE2(6), INST_MODE);
}

unsigned char login(unsigned char key, unsigned char reset_password)
{
    static char entered_password[5];
    static unsigned char entered_count;
    static unsigned char attempts_left;
    char stored_password[5];
    unsigned char last_second;

    if (reset_password == RESET_PASSWORD)
    {
        entered_count = 0U;
        attempts_left = 3U;
        entered_password[0] = '\0';
        show_login_prompt();
        return LOGIN_IN_PROGRESS;
    }

    if (key == SW5)
    {
        return RETURN_BACK;
    }

    if ((key == SW1) && (entered_count < 4U))
    {
        entered_password[entered_count++] = '1';
        clcd_putch('*', LINE2((unsigned char)(6U + entered_count - 1U)));
    }
    else if ((key == SW2) && (entered_count < 4U))
    {
        entered_password[entered_count++] = '0';
        clcd_putch('*', LINE2((unsigned char)(6U + entered_count - 1U)));
    }

    if (entered_count < 4U)
    {
        return LOGIN_IN_PROGRESS;
    }

    entered_password[4] = '\0';
    get_password(stored_password);

    if (strcmp(entered_password, stored_password) == 0)
    {
        clcd_write(DISP_ON_AND_CURSOR_OFF, INST_MODE);
        clcd_write(CLEAR_DISP_SCREEN, INST_MODE);
        clcd_print("Password correct", LINE1(0));
        clcd_print("Opening menu...", LINE2(0));
        delay_ms(1000U);
        return LOGIN_SUCCESS;
    }

    attempts_left--;
    clcd_write(DISP_ON_AND_CURSOR_OFF, INST_MODE);
    clcd_write(CLEAR_DISP_SCREEN, INST_MODE);

    if (attempts_left == 0U)
    {
        clcd_print("User blocked", LINE1(2));
        clcd_print("Seconds left: 60", LINE2(0));
        sec = 60U;
        last_second = 0xFFU;

        while (sec > 0U)
        {
            if (sec != last_second)
            {
                clcd_putch((char)((sec / 10U) + '0'), LINE2(14));
                clcd_putch((char)((sec % 10U) + '0'), LINE2(15));
                last_second = sec;
            }
        }

        attempts_left = 3U;
    }
    else
    {
        clcd_print("Wrong password", LINE1(1));
        clcd_putch((char)(attempts_left + '0'), LINE2(0));
        clcd_print(" attempts left", LINE2(1));
        delay_ms(2000U);
    }

    entered_count = 0U;
    entered_password[0] = '\0';
    show_login_prompt();
    return LOGIN_IN_PROGRESS;
}

static void draw_menu(unsigned char menu_position)
{
    clcd_write(CLEAR_DISP_SCREEN, INST_MODE);

    if (menu_position == 0U)
    {
        clcd_putch('*', LINE1(0));
        clcd_print(menu[0], LINE1(2));
        clcd_print(menu[1], LINE2(2));
    }
    else
    {
        clcd_print(menu[menu_position - 1U], LINE1(2));
        clcd_putch('*', LINE2(0));
        clcd_print(menu[menu_position], LINE2(2));
    }
}

unsigned char login_menu(unsigned char key, unsigned char reset_menu)
{
    static unsigned char menu_position;

    if (reset_menu == RESET_LOGIN_MENU)
    {
        menu_position = 0U;
        draw_menu(menu_position);
        return menu_position;
    }

    if (key == SW1)
    {
        if (menu_position == 0U)
        {
            menu_position = 4U;
        }
        else
        {
            menu_position--;
        }
        draw_menu(menu_position);
    }
    else if (key == SW2)
    {
        menu_position++;
        if (menu_position >= 5U)
        {
            menu_position = 0U;
        }
        draw_menu(menu_position);
    }

    return menu_position;
}

static void display_log_record(unsigned char order)
{
    char record[LOG_RECORD_SIZE];

    read_log_record(order, record);

    clear_line(LINE2(0));
    clcd_putch((char)(order + '0'), LINE2(0));
    clcd_putch(record[0], LINE2(2));
    clcd_putch(record[1], LINE2(3));
    clcd_putch(':', LINE2(4));
    clcd_putch(record[2], LINE2(5));
    clcd_putch(record[3], LINE2(6));
    clcd_putch(':', LINE2(7));
    clcd_putch(record[4], LINE2(8));
    clcd_putch(record[5], LINE2(9));
    clcd_putch(record[6], LINE2(11));
    clcd_putch(record[7], LINE2(12));
    clcd_putch(record[8], LINE2(14));
    clcd_putch(record[9], LINE2(15));
}

void view_log(unsigned char key, unsigned char reset_position)
{
    static unsigned char position;
    static unsigned char screen_initialized;
    static unsigned char displayed_position;
    unsigned char redraw_record = 0U;

    if (reset_position == RESET_VIEW_LOG_POS)
    {
        position = 0U;
        displayed_position = 0xFFU;
        screen_initialized = 0U;
    }

    /*
     * Do not clear and rewrite the LCD on every main-loop iteration.
     * Repeated CLEAR commands make the HD44780 display visibly blink and
     * can leave partial text in PICSimLab while the simulator catches up.
     */
    if (log_count == 0U)
    {
        if (!screen_initialized)
        {
            clcd_write(CLEAR_DISP_SCREEN, INST_MODE);
            clcd_print("No logs are", LINE1(2));
            clcd_print("there to display", LINE2(0));
            screen_initialized = 1U;
        }
        return;
    }

    if (!screen_initialized)
    {
        clcd_write(CLEAR_DISP_SCREEN, INST_MODE);
        clcd_print("# TIME     EV SP", LINE1(0));
        screen_initialized = 1U;
        redraw_record = 1U;
    }

    if ((key == SW1) && (position > 0U))
    {
        position--;
        redraw_record = 1U;
    }
    else if ((key == SW2) && ((position + 1U) < log_count))
    {
        position++;
        redraw_record = 1U;
    }

    if (displayed_position != position)
    {
        redraw_record = 1U;
    }

    if (redraw_record)
    {
        display_log_record(position);
        displayed_position = position;
    }
}

unsigned char clear_log(unsigned char reset_memory)
{
    unsigned char address;

    if (reset_memory != RESET_MEMORY)
    {
        return TASK_FAIL;
    }

    clcd_write(CLEAR_DISP_SCREEN, INST_MODE);
    clcd_print("Logs are", LINE1(4));
    clcd_print("Clearing...", LINE2(3));

    log_write_index = 0U;
    log_count = 0U;
    write_log_metadata();

    for (address = LOG_START_ADDR;
         address < (LOG_START_ADDR + (MAX_LOGS * LOG_RECORD_SIZE));
         address++)
    {
        ext_eeprom_24C02_byte_write(address, 0xFFU);
    }

    delay_ms(2000U);
    return TASK_SUCCESS;
}

static void uart_print_log(unsigned char order, const char record[LOG_RECORD_SIZE])
{
    putchars((unsigned char)(order + '0'));
    putchars(' ');
    putchars((unsigned char)record[0]);
    putchars((unsigned char)record[1]);
    putchars(':');
    putchars((unsigned char)record[2]);
    putchars((unsigned char)record[3]);
    putchars(':');
    putchars((unsigned char)record[4]);
    putchars((unsigned char)record[5]);
    putchars(' ');
    putchars((unsigned char)record[6]);
    putchars((unsigned char)record[7]);
    putchars(' ');
    putchars((unsigned char)record[8]);
    putchars((unsigned char)record[9]);
    putsx("\r\n");
}

void download_log(void)
{
    unsigned char order;
    char record[LOG_RECORD_SIZE];

    clcd_write(CLEAR_DISP_SCREEN, INST_MODE);
    clcd_print("Logs are", LINE1(4));
    clcd_print("Downloading...", LINE2(1));

    putsx("# TIME     EV SP\r\n");

    if (log_count == 0U)
    {
        putsx("No logs are there to display\r\n");
    }
    else
    {
        for (order = 0U; order < log_count; order++)
        {
            read_log_record(order, record);
            uart_print_log(order, record);
        }
    }

    uart_flush();
    delay_ms(2000U);
}

static void draw_time_editor(const unsigned char new_time[3],
                             unsigned char selected_field,
                             unsigned char hide_selected)
{
    clcd_putch((char)((new_time[0] / 10U) + '0'), LINE2(0));
    clcd_putch((char)((new_time[0] % 10U) + '0'), LINE2(1));
    clcd_putch(':', LINE2(2));
    clcd_putch((char)((new_time[1] / 10U) + '0'), LINE2(3));
    clcd_putch((char)((new_time[1] % 10U) + '0'), LINE2(4));
    clcd_putch(':', LINE2(5));
    clcd_putch((char)((new_time[2] / 10U) + '0'), LINE2(6));
    clcd_putch((char)((new_time[2] % 10U) + '0'), LINE2(7));
    clcd_print(" H  M  S", LINE2(8));

    if (hide_selected)
    {
        if (selected_field == 0U)
        {
            clcd_print("  ", LINE2(0));
        }
        else if (selected_field == 1U)
        {
            clcd_print("  ", LINE2(3));
        }
        else
        {
            clcd_print("  ", LINE2(6));
        }
    }
}

unsigned char change_time(unsigned char key, unsigned char reset_time)
{
    static unsigned char new_time[3];
    static unsigned char selected_field;
    static unsigned char last_blink_tick;
    static unsigned char blink_state;

    if (reset_time == RESET_TIME)
    {
        get_time();
        new_time[0] = (unsigned char)(((time[0] - '0') * 10) +
                                      (time[1] - '0'));
        new_time[1] = (unsigned char)(((time[2] - '0') * 10) +
                                      (time[3] - '0'));
        new_time[2] = (unsigned char)(((time[4] - '0') * 10) +
                                      (time[5] - '0'));
        selected_field = 0U;
        last_blink_tick = half_second_tick;
        blink_state = 0U;
        clcd_write(CLEAR_DISP_SCREEN, INST_MODE);
        clcd_print("Time (HH:MM:SS)", LINE1(0));
        draw_time_editor(new_time, selected_field, 0U);
        return TASK_FAIL;
    }

    if (key == SW1)
    {
        new_time[selected_field]++;

        if ((selected_field == 0U) && (new_time[0] > 23U))
        {
            new_time[0] = 0U;
        }
        else if ((selected_field != 0U) &&
                 (new_time[selected_field] > 59U))
        {
            new_time[selected_field] = 0U;
        }
        blink_state = 0U;
        last_blink_tick = half_second_tick;
        draw_time_editor(new_time, selected_field, 0U);
    }
    else if (key == SW2)
    {
        selected_field++;
        if (selected_field >= 3U)
        {
            selected_field = 0U;
        }
        blink_state = 0U;
        last_blink_tick = half_second_tick;
        draw_time_editor(new_time, selected_field, 0U);
    }
    else if (key == SW4)
    {
        write_ds1307(HOUR_ADDR,
                     (unsigned char)(((new_time[0] / 10U) << 4) |
                                      (new_time[0] % 10U)));
        write_ds1307(MIN_ADDR,
                     (unsigned char)(((new_time[1] / 10U) << 4) |
                                      (new_time[1] % 10U)));
        write_ds1307(SEC_ADDR,
                     (unsigned char)(((new_time[2] / 10U) << 4) |
                                      (new_time[2] % 10U)));

        clcd_write(CLEAR_DISP_SCREEN, INST_MODE);
        clcd_print("Time changed", LINE1(2));
        clcd_print("Successfully", LINE2(2));
        delay_ms(2000U);
        return TASK_SUCCESS;
    }

    if (half_second_tick != last_blink_tick)
    {
        last_blink_tick = half_second_tick;
        blink_state = (unsigned char)!blink_state;
        draw_time_editor(new_time, selected_field, blink_state);
    }

    return TASK_FAIL;
}

static void save_password(const char password[4])
{
    unsigned char index;

    for (index = 0U; index < 4U; index++)
    {
        ext_eeprom_24C02_byte_write((unsigned char)(PASSWORD_ADDR + index),
                                    (unsigned char)password[index]);
    }
    ext_eeprom_24C02_byte_write(PASSWORD_MAGIC_ADDR, PASSWORD_MAGIC);
}

unsigned char change_password(unsigned char key, unsigned char reset_password)
{
    static char entered[8];
    static unsigned char position;
    char digit;

    if (reset_password == RESET_PASSWORD)
    {
        position = 0U;
        memset(entered, 0, sizeof(entered));
        clcd_write(CLEAR_DISP_SCREEN, INST_MODE);
        clcd_print("Enter new pwd", LINE1(1));
        clear_line(LINE2(0));
        clcd_write(DISP_ON_AND_CURSOR_ON, INST_MODE);
        clcd_write(LINE2(6), INST_MODE);
        return TASK_FAIL;
    }

    if (key == SW1)
    {
        digit = '1';
    }
    else if (key == SW2)
    {
        digit = '0';
    }
    else
    {
        return TASK_FAIL;
    }

    if (position < 8U)
    {
        entered[position] = digit;
        clcd_putch('*', LINE2((unsigned char)(6U + (position % 4U))));
        position++;
    }

    if (position == 4U)
    {
        delay_ms(300U);
        clcd_write(CLEAR_DISP_SCREEN, INST_MODE);
        clcd_print("Re-enter new pwd", LINE1(0));
        clear_line(LINE2(0));
        clcd_write(LINE2(6), INST_MODE);
        return TASK_FAIL;
    }

    if (position < 8U)
    {
        return TASK_FAIL;
    }

    clcd_write(DISP_ON_AND_CURSOR_OFF, INST_MODE);
    clcd_write(CLEAR_DISP_SCREEN, INST_MODE);

    if (strncmp(entered, &entered[4], 4U) == 0)
    {
        save_password(entered);
        clcd_print("Password changed", LINE1(0));
        clcd_print("Successfully", LINE2(2));
    }
    else
    {
        clcd_print("Passwords do", LINE1(2));
        clcd_print("not match", LINE2(4));
    }

    delay_ms(2000U);
    return TASK_SUCCESS;
}
