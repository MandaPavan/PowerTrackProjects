#ifndef DISPLAY_H
#define DISPLAY_H

void storage_init(void);

void display_dash_board(const char event[], unsigned char speed);
void display_time(void);
void get_time(void);

unsigned char login(unsigned char key, unsigned char reset_password);
unsigned char login_menu(unsigned char key, unsigned char reset_menu);

void log_car_event(const char *event, unsigned char speed);
void view_log(unsigned char key, unsigned char reset_position);
unsigned char clear_log(unsigned char reset_memory);
void download_log(void);

unsigned char change_time(unsigned char key, unsigned char reset_time);
void get_password(char *password);
unsigned char change_password(unsigned char key, unsigned char reset_password);

#endif /* DISPLAY_H */
