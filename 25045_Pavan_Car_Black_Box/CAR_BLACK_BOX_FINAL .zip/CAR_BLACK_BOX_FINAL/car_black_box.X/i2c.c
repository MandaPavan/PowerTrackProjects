#include <xc.h>
#include "I2C.h"

void init_i2c(unsigned long baud)
{
    TRISC3 = 1;
    TRISC4 = 1;

    /* Standard-speed I2C, master mode with SSP enabled. */
    SSPSTAT = 0x80U;
    SSPCON = 0x28U;
    SSPADD = (unsigned char)((FOSC / (4UL * baud)) - 1UL);
}

static void i2c_wait_for_idle(void)
{
    while (R_nW || (SSPCON2 & 0x1FU))
    {
        ;
    }
}

void i2c_start(void)
{
    i2c_wait_for_idle();
    SEN = 1;
    i2c_wait_for_idle();
}

void i2c_rep_start(void)
{
    i2c_wait_for_idle();
    RSEN = 1;
    i2c_wait_for_idle();
}

void i2c_stop(void)
{
    i2c_wait_for_idle();
    PEN = 1;
    i2c_wait_for_idle();
}

unsigned char i2c_read(unsigned char send_ack)
{
    unsigned char data;

    i2c_wait_for_idle();
    RCEN = 1;
    i2c_wait_for_idle();
    data = SSPBUF;

    /* ACKDT = 0 sends ACK; ACKDT = 1 sends NACK. */
    ACKDT = send_ack ? 0 : 1;
    ACKEN = 1;
    i2c_wait_for_idle();

    return data;
}

int i2c_write(unsigned char data)
{
    i2c_wait_for_idle();
    SSPBUF = data;
    i2c_wait_for_idle();

    return !ACKSTAT;
}
