#include <xc.h>
#include "timer2.h"

volatile unsigned char sec;
volatile unsigned char half_second_tick;

void __interrupt() isr(void)
{
    static unsigned int one_second_count = 0U;
    static unsigned int half_second_count = 0U;

    if (TMR2IF == 1)
    {
        one_second_count++;
        half_second_count++;

        if (half_second_count >= 625U)
        {
            half_second_count = 0U;
            half_second_tick++;
        }

        if (one_second_count >= 1250U)
        {
            one_second_count = 0U;
            if (sec > 0U)
            {
                sec--;
            }
        }

        TMR2IF = 0;
    }
}
