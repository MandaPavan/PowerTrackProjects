/*
 * Project     : Car Black Box
 * Author      : MANDA PAVAN KALYAN
 * Date        : 21/06/2026
 * Controller  : PIC16F877A
 * Description : Records time, vehicle event and speed in external EEPROM.
 *
 * Dashboard switch mapping (short-press, press-edge triggered):
 * SW1 - Increase gear
 * SW2 - Decrease gear
 * SW3 - Collision
 * SW4 - Login screen
 */

#include "main.h"

#pragma config FOSC = HS
#pragma config WDTE = OFF
#pragma config PWRTE = ON
#pragma config BOREN = ON
#pragma config LVP = OFF
#pragma config CPD = OFF
#pragma config WRT = OFF
#pragma config CP = OFF

#define GEAR_COUNT 7U

static const char * const gear[GEAR_COUNT] =
{
    "GN", "G1", "G2", "G3", "G4", "G5", "GR"
};

static void init_config(void)
{
    /* Configure AN0 and make the remaining analogue-capable pins digital
       before using RE1/RE2 as CLCD control pins. */
    init_adc();
    init_clcd();
    init_i2c(100000UL);
    init_ds1307();
    init_digital_keypad();
    init_timer2();
    init_uart(9600UL);

    GIE = 1;
    PEIE = 1;
    TMR2ON = 1;
}

static unsigned char get_vehicle_speed(void)
{
    unsigned long adc_value;

    adc_value = read_adc();
    return (unsigned char)((adc_value * 99UL) / 1023UL);
}

static void set_event(char event[3], const char *new_event)
{
    event[0] = new_event[0];
    event[1] = new_event[1];
    event[2] = '\0';
}

void main(void)
{
    char event[3] = "ON";
    unsigned char key;
    unsigned char speed;
    unsigned char control_flag = DASH_BOARD_FLAG;
    unsigned char reset_flag = RESET_NOTHING;
    unsigned char active_reset;
    unsigned char menu_pos = 0;
    unsigned char gear_pos = 0;
    unsigned char collision_active = 0;
    unsigned char result;

    init_config();
    storage_init();

    speed = get_vehicle_speed();
    log_car_event(event, speed);
    clcd_write(CLEAR_DISP_SCREEN, INST_MODE);

    while (1)
    {
        active_reset = reset_flag;
        reset_flag = RESET_NOTHING;

        speed = get_vehicle_speed();
        key = read_digital_keypad();

        switch (control_flag)
        {
            case DASH_BOARD_FLAG:
                /* Vehicle controls are processed only on the dashboard. */
                if (key == SW1)
                {
                    if (collision_active)
                    {
                        gear_pos = 0;
                        collision_active = 0;
                    }
                    else if (gear_pos < (GEAR_COUNT - 1U))
                    {
                        gear_pos++;
                    }
                    else
                    {
                        break;
                    }

                    set_event(event, gear[gear_pos]);
                    log_car_event(event, speed);
                }
                else if (key == SW2)
                {
                    if (collision_active)
                    {
                        gear_pos = 0;
                        collision_active = 0;
                    }
                    else if (gear_pos > 0U)
                    {
                        gear_pos--;
                    }
                    else
                    {
                        break;
                    }

                    set_event(event, gear[gear_pos]);
                    log_car_event(event, speed);
                }
                else if (key == SW3)
                {
                    set_event(event, "C ");
                    collision_active = 1;
                    log_car_event(event, speed);
                }
                else if (key == SW4)
                {
                    control_flag = LOGIN_FLAG;
                    reset_flag = RESET_PASSWORD;
                    clcd_write(CLEAR_DISP_SCREEN, INST_MODE);
                    break;
                }

                display_dash_board(event, speed);
                break;

            case LOGIN_FLAG:
                result = login(key, active_reset);
                if (result == LOGIN_SUCCESS)
                {
                    control_flag = LOGIN_MENU_FLAG;
                    reset_flag = RESET_LOGIN_MENU;
                    clcd_write(DISP_ON_AND_CURSOR_OFF, INST_MODE);
                    clcd_write(CLEAR_DISP_SCREEN, INST_MODE);
                }
                else if (result == RETURN_BACK)
                {
                    control_flag = DASH_BOARD_FLAG;
                    clcd_write(DISP_ON_AND_CURSOR_OFF, INST_MODE);
                    clcd_write(CLEAR_DISP_SCREEN, INST_MODE);
                }
                break;

            case LOGIN_MENU_FLAG:
                if (key == SW5)
                {
                    control_flag = DASH_BOARD_FLAG;
                    clcd_write(CLEAR_DISP_SCREEN, INST_MODE);
                }
                else if (key == SW4)
                {
                    switch (menu_pos)
                    {
                        case 0:
                            control_flag = VIEW_LOG_FLAG;
                            reset_flag = RESET_VIEW_LOG_POS;
                            clcd_write(CLEAR_DISP_SCREEN, INST_MODE);
                            break;

                        case 1:
                            control_flag = CLEAR_LOG_FLAG;
                            reset_flag = RESET_MEMORY;
                            clcd_write(CLEAR_DISP_SCREEN, INST_MODE);
                            break;

                        case 2:
                            log_car_event("DL", speed);
                            control_flag = DOWNLOAD_LOG_FLAG;
                            clcd_write(CLEAR_DISP_SCREEN, INST_MODE);
                            break;

                        case 3:
                            log_car_event("ST", speed);
                            control_flag = SET_TIME_FLAG;
                            reset_flag = RESET_TIME;
                            clcd_write(CLEAR_DISP_SCREEN, INST_MODE);
                            break;

                        case 4:
                            log_car_event("CP", speed);
                            control_flag = CHANGE_PASSWORD_FLAG;
                            reset_flag = RESET_PASSWORD;
                            clcd_write(CLEAR_DISP_SCREEN, INST_MODE);
                            break;

                        default:
                            menu_pos = 0;
                            reset_flag = RESET_LOGIN_MENU;
                            break;
                    }
                }
                else
                {
                    menu_pos = login_menu(key, active_reset);
                }
                break;

            case VIEW_LOG_FLAG:
                if (key == SW5)
                {
                    control_flag = LOGIN_MENU_FLAG;
                    reset_flag = RESET_LOGIN_MENU;
                    clcd_write(CLEAR_DISP_SCREEN, INST_MODE);
                }
                else
                {
                    view_log(key, active_reset);
                }
                break;

            case CLEAR_LOG_FLAG:
                clear_log(active_reset);
                control_flag = LOGIN_MENU_FLAG;
                reset_flag = RESET_LOGIN_MENU;
                clcd_write(CLEAR_DISP_SCREEN, INST_MODE);
                break;

            case DOWNLOAD_LOG_FLAG:
                download_log();
                control_flag = LOGIN_MENU_FLAG;
                reset_flag = RESET_LOGIN_MENU;
                clcd_write(CLEAR_DISP_SCREEN, INST_MODE);
                break;

            case SET_TIME_FLAG:
                if (key == SW5)
                {
                    control_flag = LOGIN_MENU_FLAG;
                    reset_flag = RESET_LOGIN_MENU;
                    clcd_write(CLEAR_DISP_SCREEN, INST_MODE);
                }
                else if (change_time(key, active_reset) == TASK_SUCCESS)
                {
                    control_flag = DASH_BOARD_FLAG;
                    clcd_write(CLEAR_DISP_SCREEN, INST_MODE);
                }
                break;

            case CHANGE_PASSWORD_FLAG:
                if (key == SW5)
                {
                    control_flag = LOGIN_MENU_FLAG;
                    reset_flag = RESET_LOGIN_MENU;
                    clcd_write(DISP_ON_AND_CURSOR_OFF, INST_MODE);
                    clcd_write(CLEAR_DISP_SCREEN, INST_MODE);
                }
                else if (change_password(key, active_reset) == TASK_SUCCESS)
                {
                    control_flag = LOGIN_MENU_FLAG;
                    reset_flag = RESET_LOGIN_MENU;
                    clcd_write(DISP_ON_AND_CURSOR_OFF, INST_MODE);
                    clcd_write(CLEAR_DISP_SCREEN, INST_MODE);
                }
                break;

            default:
                control_flag = DASH_BOARD_FLAG;
                clcd_write(CLEAR_DISP_SCREEN, INST_MODE);
                break;
        }

    }
}
