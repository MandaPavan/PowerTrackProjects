#include <xc.h>
#include "timer2.h"

void init_timer2(void)
{
    /* Fosc=20 MHz, instruction clock=5 MHz, prescaler 1:16. */
    T2CKPS0 = 1;
    T2CKPS1 = 1;
    PR2 = 250U;
    TMR2 = 0U;
    TMR2IF = 0;
    TMR2IE = 1;
    TMR2ON = 0;
}
