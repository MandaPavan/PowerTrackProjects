#include <xc.h>
#include "uart.h"

void init_uart(unsigned long baud)
{
    TRISC6 = 0;
    TRISC7 = 1;
    SYNC = 0;
    TX9 = 0;
    RX9 = 0;
    SPEN = 1;
    BRGH = 1;
    TXEN = 1;
    CREN = 1;
    SPBRG = (unsigned char)((FOSC / (16UL * baud)) - 1UL);
}

void putchars(unsigned char data)
{
    while (!TXIF)
    {
        ;
    }
    TXREG = data;
}

void putsx(const char *string)
{
    while (*string != '\0')
    {
        putchars((unsigned char)*string);
        string++;
    }
}

void uart_flush(void)
{
    while (!TRMT)
    {
        ;
    }
}
