#ifndef UART_H
#define UART_H

#define FOSC 20000000UL

void init_uart(unsigned long baud);
void putchars(unsigned char data);
void putsx(const char *string);
void uart_flush(void);

#endif /* UART_H */
