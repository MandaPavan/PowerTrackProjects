#include "clcd.h"

/*
 * Generate the LCD enable pulse.
 */
static void clcd_pulse_enable(void)
{
    CLCD_EN = HI;
    __delay_us(2);

    CLCD_EN = LOW;
}

/*
 * Send one instruction or one data byte to the LCD in 4-bit mode.
 */
static void clcd_write(unsigned char byte, unsigned char mode)
{
    /*
     * mode = INST_MODE for command
     * mode = DATA_MODE for display data
     */
    CLCD_RS = (mode != 0U) ? HI : LOW;

    /*
     * Send upper nibble through RD4-RD7.
     *
     * RD0-RD3 remain LOW during the LCD transaction.
     */
    CLCD_DATA_PORT = (unsigned char)(byte & 0xF0U);

    clcd_pulse_enable();

    /*
     * Send lower nibble through RD4-RD7.
     */
    CLCD_DATA_PORT =
        (unsigned char)((byte & 0x0FU) << 4U);

    clcd_pulse_enable();

    /*
     * The LCD has now latched both nibbles.
     *
     * Clear the complete PORTD immediately so:
     *
     * 1. PORTD LEDs do not remain illuminated.
     * 2. Seven-segment segment lines do not retain the LCD data.
     * 3. Keypad rows remain LOW while idle.
     */
    CLCD_DATA_PORT = 0x00U;

    /*
     * Allow the LCD command to complete.
     */
    __delay_us(60);
}

/*
 * Initialize the HD44780 LCD controller in 4-bit mode.
 */
static void init_display_controller(void)
{
    /*
     * Wait for LCD power-up.
     */
    __delay_ms(30);

    /*
     * Standard HD44780 4-bit initialization sequence.
     */
    clcd_write(EIGHT_BIT_MODE, INST_MODE);
    __delay_ms(5);

    clcd_write(EIGHT_BIT_MODE, INST_MODE);
    __delay_us(150);

    clcd_write(EIGHT_BIT_MODE, INST_MODE);

    /*
     * Change to 4-bit interface mode.
     */
    clcd_write(FOUR_BIT_MODE, INST_MODE);

    /*
     * Configure two-line mode with 5x8 character font.
     * The same addressing is used for the PICSimLab 16x4 LCD.
     */
    clcd_write(TWO_LINES_5x8_4_BIT_MODE, INST_MODE);

    /*
     * Clear the LCD.
     */
    clcd_write(CLEAR_DISP_SCREEN, INST_MODE);
    __delay_ms(2);

    /*
     * Display ON, cursor OFF and blinking cursor OFF.
     */
    clcd_write(DISP_ON_AND_CURSOR_OFF, INST_MODE);
}

/*
 * Configure LCD pins and initialize the LCD controller.
 */
void init_clcd(void)
{
    /*
     * RD4-RD7 are LCD data outputs.
     *
     * Clearing TRISD bits 4-7 configures the high nibble
     * as output while retaining the low-nibble configuration.
     */
    CLCD_DATA_PORT_DDR &= 0x0FU;

    /*
     * LCD RS and EN are outputs.
     */
    CLCD_RS_DDR = 0U;
    CLCD_EN_DDR = 0U;

    /*
     * Initial pin states.
     */
    CLCD_RS = LOW;
    CLCD_EN = LOW;
    CLCD_DATA_PORT = 0x00U;

    init_display_controller();
}

/*
 * Display one character at the specified LCD address.
 */
void clcd_putch(char data, unsigned char addr)
{
    /*
     * Select LCD position.
     */
    clcd_write(addr, INST_MODE);

    /*
     * Display character.
     */
    clcd_write((unsigned char)data, DATA_MODE);
}

/*
 * Display a null-terminated string at the specified LCD address.
 */
void clcd_print(const char *str, unsigned char addr)
{
    /*
     * Select the starting LCD position.
     */
    clcd_write(addr, INST_MODE);

    /*
     * Display each character until the string terminator.
     */
    while (*str != '\0')
    {
        clcd_write((unsigned char)*str, DATA_MODE);
        str++;
    }
}

/*
 * Clear the complete LCD screen.
 */
void clear_screen(void)
{
    clcd_write(CLEAR_DISP_SCREEN, INST_MODE);

    /*
     * Clear-display command requires additional execution time.
     */
    __delay_ms(2);
}