#ifndef CLCD_H
#define CLCD_H

#include "main.h"

#define CLCD_DATA_PORT_DDR          TRISD
#define CLCD_RS_DDR                 TRISE2
#define CLCD_EN_DDR                 TRISE1

#define CLCD_DATA_PORT              PORTD
#define CLCD_RS                     RE2
#define CLCD_EN                     RE1

#define INST_MODE                   0
#define DATA_MODE                   1

#define HI                          1
#define LOW                         0

/* PICSimLab is configured for the HD44780 16x4 display. */
#define LINE1(x)                    (0x80U + (x))
#define LINE2(x)                    (0xC0U + (x))
#define LINE3(x)                    (0x90U + (x))
#define LINE4(x)                    (0xD0U + (x))

#define EIGHT_BIT_MODE              0x33
#define FOUR_BIT_MODE               0x02
#define TWO_LINES_5x8_4_BIT_MODE    0x28
#define CLEAR_DISP_SCREEN           0x01
#define DISP_ON_AND_CURSOR_OFF      0x0C
#define BAR                         0xFF

void init_clcd(void);
void clcd_putch(char data, unsigned char addr);
void clcd_print(const char *str, unsigned char addr);
void clear_screen(void);

#endif
