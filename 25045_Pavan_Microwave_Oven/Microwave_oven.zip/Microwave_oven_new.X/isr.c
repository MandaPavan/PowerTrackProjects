#include "main.h"
#include "timers.h"

volatile unsigned char timer_half_second_events = 0;
volatile unsigned char timer_one_second_events = 0;

void __interrupt() isr(void)
{
    static unsigned char interrupt_count = 0;
    static unsigned char half_phase = 0;

    if (TMR2IF != 0U)
    {
        TMR2IF = 0;

        interrupt_count++;
        if (interrupt_count >= 39U)
        {
            interrupt_count = 0;

            if (timer_half_second_events < 0xFFU)
            {
                timer_half_second_events++;
            }

            half_phase ^= 1U;
            if (half_phase == 0U)
            {
                if (timer_one_second_events < 0xFFU)
                {
                    timer_one_second_events++;
                }
            }
        }
    }
}
