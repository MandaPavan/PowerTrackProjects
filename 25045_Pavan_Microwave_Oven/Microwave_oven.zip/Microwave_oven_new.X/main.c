/*
 * Project Name : MICROWAVE OVEN CONTROLLER USING PIC16F877A
 * Author       : MANDA PAVAN KALYAN
 * Date         : 27 June 2026
 * Description  : Microwave oven controller using PIC16F877A,
 *                16x4 CLCD, matrix keypad, Timer2, fan and buzzer.
 */

#include "main.h"
#include "clcd.h"
#include "matrix_keypad.h"
#include "micro_oven_def.h"
#include "timers.h"

/*
 * PIC16F877A configuration bits.
 * PICSimLab clock must be set to 20 MHz.
 */
#pragma config FOSC = HS
#pragma config WDTE = OFF
#pragma config PWRTE = ON
#pragma config BOREN = ON
#pragma config LVP = OFF
#pragma config CPD = OFF
#pragma config WRT = OFF
#pragma config CP = OFF

void init_config(void)
{
    /*
     * Configure PORTA and PORTE pins as digital I/O.
     */
    ADCON1 = 0x06U;

    /*
     * PICGenios seven-segment display selectors:
     *
     * RA2 -> DISP1
     * RA3 -> DISP2
     * RA4 -> DISP3
     * RA5 -> DISP4
     *
     * Configure all selector pins as outputs and keep them LOW.
     * This prevents all four seven-segment displays from remaining ON.
     */
    PORTA &= 0xC3U;
    TRISA &= 0xC3U;

    /*
     * Fan and buzzer outputs.
     */
    FAN_DDR = 0U;
    BUZZER_DDR = 0U;

    FAN = OFF;
    BUZZER = OFF;

    /*
     * Initialize peripherals.
     */
    init_clcd();
    init_matrix_keypad();
    init_timer2();

    /*
     * Enable peripheral and global interrupts.
     */
    PEIE = 1U;
    GIE = 1U;
}

void main(void)
{
    unsigned char key;

    init_config();
    micro_oven_init();

    while (1)
    {
        /*
         * STATE mode provides one event for each short key press.
         * Holding a key does not repeatedly generate the same input.
         */
        key = read_matrix_keypad(STATE);

        /*
         * Execute the microwave state-machine logic.
         */
        micro_oven_task(key);
    }
}