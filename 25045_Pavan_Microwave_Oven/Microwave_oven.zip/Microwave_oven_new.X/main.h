#ifndef MAIN_H
#define MAIN_H

#define _XTAL_FREQ 20000000UL

#include <xc.h>

void init_config(void);

#endif
