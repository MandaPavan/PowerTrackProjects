/*
 * Project Name : MICROWAVE OVEN CONTROLLER USING PIC16F877A
 * Author       : MANDA PAVAN KALYAN
 * Date         : 27 June 2026
 * File         : matrix_keypad.c
 *
 * Description:
 * Reads only the 3x4 numeric matrix keypad.
 *
 * Keypad rows:
 * ROW1 = RD3 -> 1, 2, 3
 * ROW2 = RD2 -> 4, 5, 6
 * ROW3 = RD1 -> 7, 8, 9
 * ROW4 = RD0 -> *, 0, #
 *
 * Keypad columns:
 * COL1 = RB0
 * COL2 = RB1
 * COL3 = RB2
 *
 * The separate RB0, RB1 and RB2 pushbuttons are rejected.
 * PORTD row pins remain inputs while idle so PORTD LEDs and
 * seven-segment segments do not remain illuminated.
 */

#include "matrix_keypad.h"

/*
 * Scan the keypad once.
 */
static unsigned char scan_keypad(void)
{
    /*
     * TRISD lower-nibble patterns.
     *
     * 1 = input/high impedance
     * 0 = output LOW
     *
     * Only one keypad row is configured as an output at a time.
     */
    static const unsigned char row_tris_pattern[4] =
    {
        0x07U, /* RD3 output LOW: keys 1, 2, 3 */
        0x0BU, /* RD2 output LOW: keys 4, 5, 6 */
        0x0DU, /* RD1 output LOW: keys 7, 8, 9 */
        0x0EU  /* RD0 output LOW: keys *, 0, # */
    };

    static const unsigned char key_map[4][3] =
    {
        {1U,   2U,  3U},
        {4U,   5U,  6U},
        {7U,   8U,  9U},
        {'*',  0U, '#'}
    };

    unsigned char row;
    unsigned char columns;
    unsigned char detected_key;
    unsigned char detected_count;

    detected_key = ALL_RELEASED;
    detected_count = 0U;

    /*
     * Keep the PORTD output latch LOW.
     *
     * RD4-RD7 are used by the LCD, but the LCD has already
     * latched its data before keypad scanning occurs.
     */
    PORTD = 0x00U;

    /*
     * Initially configure every keypad row as an input.
     */
    TRISD = (unsigned char)((TRISD & 0xF0U) | 0x0FU);

    for (row = 0U; row < 4U; row++)
    {
        /*
         * Keep RD4-RD7 configuration unchanged.
         * Configure only the selected keypad row as output LOW.
         * All other keypad rows remain inputs/high impedance.
         */
        TRISD = (unsigned char)
        (
            (TRISD & 0xF0U) |
            row_tris_pattern[row]
        );

        /*
         * Ensure the selected output row is LOW.
         */
        PORTD = 0x00U;

        /*
         * Allow signals to settle before reading columns.
         */
        __delay_us(50);

        /*
         * Read RB0, RB1 and RB2.
         *
         * 111 = no key pressed
         * 110 = column 1 pressed
         * 101 = column 2 pressed
         * 011 = column 3 pressed
         */
        columns = (unsigned char)(PORTB & 0x07U);

        if (columns == 0x06U)
        {
            detected_key = key_map[row][0];
            detected_count++;
        }
        else if (columns == 0x05U)
        {
            detected_key = key_map[row][1];
            detected_count++;
        }
        else if (columns == 0x03U)
        {
            detected_key = key_map[row][2];
            detected_count++;
        }
        else if (columns != 0x07U)
        {
            /*
             * Invalid condition:
             * more than one column is active.
             */
            detected_count = 2U;
        }
        else
        {
            /*
             * No key detected in this row.
             */
        }

        /*
         * Return all keypad rows to inputs before scanning
         * the next row.
         */
        TRISD = (unsigned char)((TRISD & 0xF0U) | 0x0FU);
    }

    /*
     * Idle condition:
     * all keypad rows are inputs and PORTD latch is LOW.
     *
     * This prevents the PORTD LEDs from remaining ON.
     */
    TRISD = (unsigned char)((TRISD & 0xF0U) | 0x0FU);
    PORTD = 0x00U;

    /*
     * A real matrix-keypad press is detected in exactly one row.
     *
     * A separate RB0, RB1 or RB2 pushbutton appears active
     * during all four row scans, so it is rejected.
     */
    if (detected_count == 1U)
    {
        return detected_key;
    }

    return ALL_RELEASED;
}

/*
 * Initialize the matrix keypad.
 */
void init_matrix_keypad(void)
{
    /*
     * RB0-RB2 are keypad-column inputs.
     */
    MATRIX_KEYPAD_COLUMN_PORT_DDR |= 0x07U;

    /*
     * Enable PORTB internal weak pull-up resistors.
     * OPTION_REG bit 7 = 0 enables PORTB pull-ups.
     */
    OPTION_REG &= 0x7FU;

    /*
     * Keep all keypad rows as inputs while idle.
     *
     * RD4-RD7 remain LCD outputs.
     */
    MATRIX_KEYPAD_ROW_PORT_DDR =
        (unsigned char)
        (
            (MATRIX_KEYPAD_ROW_PORT_DDR & 0xF0U) |
            0x0FU
        );

    /*
     * Keep the PORTD output latch LOW.
     */
    PORTD = 0x00U;
}

/*
 * Read keypad using LEVEL or STATE mode.
 */
unsigned char read_matrix_keypad(unsigned char mode)
{
    static unsigned char previous_key = ALL_RELEASED;

    unsigned char current_key;
    unsigned char confirmed_key;

    current_key = scan_keypad();

    /*
     * LEVEL mode continuously returns the currently pressed key.
     */
    if (mode == LEVEL)
    {
        return current_key;
    }

    /*
     * STATE mode:
     * produce only one event for each short key press.
     */
    if (
        (current_key != ALL_RELEASED) &&
        (previous_key == ALL_RELEASED)
       )
    {
        /*
         * Debounce the physical switch.
         */
        __delay_ms(20);

        confirmed_key = scan_keypad();

        if (confirmed_key == current_key)
        {
            previous_key = current_key;
            return current_key;
        }
    }
    else if (current_key == ALL_RELEASED)
    {
        /*
         * Key has been released.
         * Permit the next short press.
         */
        previous_key = ALL_RELEASED;
    }
    else
    {
        /*
         * Key is still held.
         * Do not return it repeatedly.
         */
    }

    return ALL_RELEASED;
}