#ifndef MATRIX_KEYPAD_H
#define MATRIX_KEYPAD_H

#include "main.h"

#define MATRIX_KEYPAD_COLUMN_PORT_DDR   TRISB
#define MATRIX_KEYPAD_ROW_PORT_DDR      TRISD

#define STATE                           1U
#define LEVEL                           0U
#define ALL_RELEASED                    0xFFU

void init_matrix_keypad(void);
unsigned char read_matrix_keypad(unsigned char mode);

#endif
