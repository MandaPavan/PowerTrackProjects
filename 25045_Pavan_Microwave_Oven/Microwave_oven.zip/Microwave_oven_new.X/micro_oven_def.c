#include "micro_oven_def.h"
#include "clcd.h"
#include "timers.h"

typedef enum
{
    OVEN_MENU,
    OVEN_SET_TIME,
    OVEN_SET_TEMP,
    OVEN_PREHEAT,
    OVEN_RUNNING,
    OVEN_PAUSED,
    OVEN_DOOR_OPEN,
    OVEN_TIME_UP
} oven_state_t;

typedef enum
{
    MODE_MICRO = 1,
    MODE_GRILL,
    MODE_CONVECTION
} oven_mode_t;

volatile unsigned char min = 0;
volatile unsigned char sec = 0;

static oven_state_t state = OVEN_MENU;
static oven_state_t resume_state = OVEN_RUNNING;
static oven_mode_t selected_mode = MODE_MICRO;

static unsigned char time_digits[4] = {0, 0, 0, 0};
static unsigned char time_digit_count = 0;
static unsigned int target_temperature = 0;
static unsigned char temp_digit_count = 0;
static unsigned char preheat_seconds = 0;
static unsigned char buzzer_seconds = 0;
static unsigned char blink_visible = 1;
static unsigned char screen_dirty = 1;
static unsigned char screen_needs_clear = 1;

static void change_state(oven_state_t next_state)
{
    state = next_state;
    screen_dirty = 1;
    screen_needs_clear = 1;
}

static void cooking_outputs(unsigned char enabled)
{
    FAN = (enabled != 0U) ? ON : OFF;
}

static void reset_time_entry(void)
{
    unsigned char i;

    for (i = 0; i < 4U; i++)
    {
        time_digits[i] = 0;
    }
    time_digit_count = 0;
    min = 0;
    sec = 0;
    blink_visible = 1;
}

static void reset_temp_entry(void)
{
    target_temperature = 0;
    temp_digit_count = 0;
    blink_visible = 1;
}

static void print_two_digits(unsigned char value, unsigned char address)
{
    clcd_putch((char)((value / 10U) + '0'), address);
    clcd_putch((char)((value % 10U) + '0'), (unsigned char)(address + 1U));
}

static void print_three_digits(unsigned int value, unsigned char address)
{
    clcd_putch((char)(((value / 100U) % 10U) + '0'), address);
    clcd_putch((char)(((value / 10U) % 10U) + '0'), (unsigned char)(address + 1U));
    clcd_putch((char)((value % 10U) + '0'), (unsigned char)(address + 2U));
}

static void show_temporary_message(const char *line2, const char *line3,
                                   unsigned int milliseconds)
{
    clear_screen();
    clcd_print(line2, LINE2(0));
    clcd_print(line3, LINE3(0));

    while (milliseconds >= 100U)
    {
        __delay_ms(100);
        milliseconds -= 100U;
    }
}

void display_power_screen(void)
{
    unsigned char i;

    clear_screen();
    for (i = 0; i < 16U; i++)
    {
        clcd_putch((char)BAR, LINE1(i));
        __delay_ms(45);
    }

    clcd_print("Powering ON", LINE2(3));
    clcd_print("Microwave Oven", LINE3(1));

    for (i = 0; i < 16U; i++)
    {
        clcd_putch((char)BAR, LINE4(i));
        __delay_ms(45);
    }
    __delay_ms(600);
}

void display_modes(void)
{
    clcd_print("1.Micro", LINE1(0));
    clcd_print("2.Grill", LINE2(0));
    clcd_print("3.Convection", LINE3(0));
    clcd_print("4.Start (30 sec)", LINE4(0));
}

static void render_set_time(void)
{
    clcd_print("SET TIME (MM:SS)", LINE1(0));
    clcd_print("TIME = 00:00    ", LINE2(0));
    clcd_print("                ", LINE3(0));
    clcd_print("*:CLEAR #:ENTER", LINE4(0));

    print_two_digits(time_digits[0] * 10U + time_digits[1], LINE2(7));
    clcd_putch((blink_visible != 0U) ? ':' : ' ', LINE2(9));
    print_two_digits(time_digits[2] * 10U + time_digits[3], LINE2(10));
}

static void render_set_temp(void)
{
    clcd_print("SET TEMP (C)    ", LINE1(0));
    clcd_print("TEMP = 000 C    ", LINE2(0));
    clcd_print("MAX = 180 C     ", LINE3(0));
    clcd_print("*:CLEAR #:ENTER", LINE4(0));

    if (blink_visible != 0U)
    {
        print_three_digits(target_temperature, LINE2(7));
    }
    else
    {
        clcd_print("   ", LINE2(7));
    }
}

static void render_preheat(void)
{
    clcd_print("CONVECTION MODE ", LINE1(0));
    clcd_print("PRE-HEATING     ", LINE2(0));
    clcd_print("TEMP=000C  060s ", LINE3(0));
    clcd_print("6:STOP          ", LINE4(0));

    print_three_digits(target_temperature, LINE3(5));
    print_three_digits(preheat_seconds, LINE3(11));
}

static void render_running(void)
{
    clcd_print("TIME = 00:00    ", LINE1(0));
    clcd_print("4:+30/RESUME    ", LINE2(0));
    clcd_print("5:PAUSE 6:STOP  ", LINE3(0));

    print_two_digits(min, LINE1(7));
    clcd_putch(':', LINE1(9));
    print_two_digits(sec, LINE1(10));

    if (selected_mode == MODE_MICRO)
    {
        clcd_print("MICRO  POWER=900", LINE4(0));
    }
    else if (selected_mode == MODE_GRILL)
    {
        clcd_print("GRILL MODE      ", LINE4(0));
    }
    else
    {
        clcd_print("CONV TEMP=000C  ", LINE4(0));
        print_three_digits(target_temperature, LINE4(10));
    }
}

static void render_paused(void)
{
    clcd_print("*** PAUSED ***  ", LINE1(0));
    clcd_print("TIME = 00:00    ", LINE2(0));
    clcd_print("4:RESUME        ", LINE3(0));
    clcd_print("6:STOP          ", LINE4(0));

    print_two_digits(min, LINE2(7));
    clcd_putch(':', LINE2(9));
    print_two_digits(sec, LINE2(10));
}

static void render_door_open(void)
{
    clcd_print("*** DOOR OPEN **", LINE1(0));
    clcd_print("Heating disabled", LINE2(0));
    clcd_print("Close the door  ", LINE3(0));
    clcd_print("4:RESUME 6:STOP ", LINE4(0));
}

static void render_time_up(void)
{
    clcd_print("*** TIME UP! ***", LINE1(0));
    clcd_print("BUZZER ON       ", LINE2(0));
    clcd_print("Enjoy your meal ", LINE3(0));
    clcd_print("                ", LINE4(0));
}

static void render_screen(void)
{
    if (screen_dirty == 0U)
    {
        return;
    }

    if (screen_needs_clear != 0U)
    {
        clear_screen();
        screen_needs_clear = 0;
    }

    switch (state)
    {
        case OVEN_MENU:
            display_modes();
            break;

        case OVEN_SET_TIME:
            render_set_time();
            break;

        case OVEN_SET_TEMP:
            render_set_temp();
            break;

        case OVEN_PREHEAT:
            render_preheat();
            break;

        case OVEN_RUNNING:
            render_running();
            break;

        case OVEN_PAUSED:
            render_paused();
            break;

        case OVEN_DOOR_OPEN:
            render_door_open();
            break;

        case OVEN_TIME_UP:
            render_time_up();
            break;

        default:
            change_state(OVEN_MENU);
            break;
    }

    screen_dirty = 0;
}

static void enter_door_open(oven_state_t interrupted_state)
{
    resume_state = interrupted_state;
    cooking_outputs(OFF);
    change_state(OVEN_DOOR_OPEN);
}

static void start_running(void)
{
    if ((min == 0U) && (sec == 0U))
    {
        show_temporary_message("INVALID TIME    ", "ENTER > 00:00   ", 1000U);
        change_state(OVEN_SET_TIME);
        return;
    }

    if (IS_DOOR_OPEN())
    {
        enter_door_open(OVEN_RUNNING);
        return;
    }

    cooking_outputs(ON);
    change_state(OVEN_RUNNING);
}

static void add_thirty_seconds(void)
{
    unsigned int total_seconds;

    total_seconds = (unsigned int)min * 60U + sec;
    if (total_seconds <= (5999U - QUICK_START_SECONDS))
    {
        total_seconds += QUICK_START_SECONDS;
    }
    else
    {
        total_seconds = 5999U;
    }

    min = (unsigned char)(total_seconds / 60U);
    sec = (unsigned char)(total_seconds % 60U);
    screen_dirty = 1;
}

static void finish_cooking(void)
{
    cooking_outputs(OFF);
    BUZZER = ON;
    buzzer_seconds = BUZZER_TIME_SECONDS;
    change_state(OVEN_TIME_UP);
}

static void stop_and_return_to_menu(void)
{
    cooking_outputs(OFF);
    BUZZER = OFF;
    min = 0;
    sec = 0;
    change_state(OVEN_MENU);
}

static void append_time_digit(unsigned char digit)
{
    if (time_digit_count < 4U)
    {
        time_digits[0] = time_digits[1];
        time_digits[1] = time_digits[2];
        time_digits[2] = time_digits[3];
        time_digits[3] = digit;
        time_digit_count++;
        screen_dirty = 1;
    }
}

static void accept_time(void)
{
    unsigned int entered_minutes;
    unsigned int entered_seconds;
    unsigned int total_seconds;

    entered_minutes = (unsigned int)time_digits[0] * 10U + time_digits[1];
    entered_seconds = (unsigned int)time_digits[2] * 10U + time_digits[3];
    total_seconds = entered_minutes * 60U + entered_seconds;

    if (total_seconds > 5999U)
    {
        total_seconds = 5999U;
    }

    min = (unsigned char)(total_seconds / 60U);
    sec = (unsigned char)(total_seconds % 60U);
    start_running();
}

static void handle_set_time_key(unsigned char key)
{
    if (key <= 9U)
    {
        append_time_digit(key);
    }
    else if (key == '*')
    {
        reset_time_entry();
        screen_dirty = 1;
    }
    else if (key == '#')
    {
        accept_time();
    }
}

static void handle_set_temp_key(unsigned char key)
{
    if (key <= 9U)
    {
        if (temp_digit_count < 3U)
        {
            target_temperature = target_temperature * 10U + key;
            temp_digit_count++;
            screen_dirty = 1;
        }
    }
    else if (key == '*')
    {
        reset_temp_entry();
        screen_dirty = 1;
    }
    else if (key == '#')
    {
        if (target_temperature == 0U)
        {
            show_temporary_message("INVALID TEMP    ", "ENTER 1 TO 180 ", 1000U);
            change_state(OVEN_SET_TEMP);
            return;
        }

        if (target_temperature > MAX_TEMPERATURE_C)
        {
            target_temperature = MAX_TEMPERATURE_C;
            show_temporary_message("TEMP LIMITED TO ", "180 DEGREES C   ", 1000U);
        }

        preheat_seconds = PREHEAT_TIME_SECONDS;
        if (IS_DOOR_OPEN())
        {
            enter_door_open(OVEN_PREHEAT);
        }
        else
        {
            cooking_outputs(ON);
            change_state(OVEN_PREHEAT);
        }
    }
}

static void handle_menu_key(unsigned char key)
{
    if (key == 1U)
    {
        selected_mode = MODE_MICRO;
        clear_screen();
        clcd_print("MICROWAVE MODE  ", LINE1(0));
        clcd_print("Power = 900W    ", LINE2(1));
        __delay_ms(1500);
        reset_time_entry();
        change_state(OVEN_SET_TIME);
    }
    else if (key == 2U)
    {
        selected_mode = MODE_GRILL;
        reset_time_entry();
        change_state(OVEN_SET_TIME);
    }
    else if (key == 3U)
    {
        selected_mode = MODE_CONVECTION;
        reset_temp_entry();
        change_state(OVEN_SET_TEMP);
    }
    else if (key == 4U)
    {
        selected_mode = MODE_MICRO;
        min = 0;
        sec = QUICK_START_SECONDS;
        start_running();
    }
}

static void process_half_second_tick(void)
{
    if ((state == OVEN_SET_TIME) || (state == OVEN_SET_TEMP))
    {
        blink_visible ^= 1U;
        screen_dirty = 1;
    }
}

static void decrement_cooking_time(void)
{
    if (sec > 0U)
    {
        sec--;
    }
    else if (min > 0U)
    {
        min--;
        sec = 59U;
    }

    screen_dirty = 1;
    if ((min == 0U) && (sec == 0U))
    {
        finish_cooking();
    }
}

static void process_one_second_tick(void)
{
    if (state == OVEN_RUNNING)
    {
        decrement_cooking_time();
    }
    else if (state == OVEN_PREHEAT)
    {
        if (preheat_seconds > 0U)
        {
            preheat_seconds--;
            screen_dirty = 1;
        }

        if (preheat_seconds == 0U)
        {
            cooking_outputs(OFF);
            reset_time_entry();
            change_state(OVEN_SET_TIME);
        }
    }
    else if (state == OVEN_TIME_UP)
    {
        if (buzzer_seconds > 0U)
        {
            buzzer_seconds--;
        }

        if (buzzer_seconds == 0U)
        {
            BUZZER = OFF;
            change_state(OVEN_MENU);
        }
    }
}

void micro_oven_init(void)
{
    display_power_screen();
    change_state(OVEN_MENU);
    render_screen();
}

void micro_oven_task(unsigned char key)
{
    /* Door safety is checked continuously, not only when a key is pressed. */
    if (((state == OVEN_RUNNING) || (state == OVEN_PREHEAT)) &&
        IS_DOOR_OPEN())
    {
        enter_door_open(state);
    }

    while (timer_take_half_second() != 0U)
    {
        process_half_second_tick();
    }

    while (timer_take_one_second() != 0U)
    {
        process_one_second_tick();
    }

    if (key != ALL_RELEASED)
    {
        switch (state)
        {
            case OVEN_MENU:
                handle_menu_key(key);
                break;

            case OVEN_SET_TIME:
                handle_set_time_key(key);
                break;

            case OVEN_SET_TEMP:
                handle_set_temp_key(key);
                break;

            case OVEN_PREHEAT:
                if (key == 6U)
                {
                    stop_and_return_to_menu();
                }
                break;

            case OVEN_RUNNING:
                if (key == 4U)
                {
                    add_thirty_seconds();
                }
                else if (key == 5U)
                {
                    cooking_outputs(OFF);
                    change_state(OVEN_PAUSED);
                }
                else if (key == 6U)
                {
                    stop_and_return_to_menu();
                }
                break;

            case OVEN_PAUSED:
                if (key == 4U)
                {
                    if (IS_DOOR_OPEN())
                    {
                        enter_door_open(OVEN_RUNNING);
                    }
                    else
                    {
                        cooking_outputs(ON);
                        change_state(OVEN_RUNNING);
                    }
                }
                else if (key == 6U)
                {
                    stop_and_return_to_menu();
                }
                break;

            case OVEN_DOOR_OPEN:
                if (key == 6U)
                {
                    stop_and_return_to_menu();
                }
                else if ((key == 4U) && !IS_DOOR_OPEN())
                {
                    cooking_outputs(ON);
                    change_state(resume_state);
                }
                break;

            case OVEN_TIME_UP:
                if (key == 6U)
                {
                    stop_and_return_to_menu();
                }
                break;

            default:
                stop_and_return_to_menu();
                break;
        }
    }

    render_screen();
}
