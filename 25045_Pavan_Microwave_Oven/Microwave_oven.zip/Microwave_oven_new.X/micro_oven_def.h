#ifndef MICRO_OVEN_DEF_H
#define MICRO_OVEN_DEF_H

#include "main.h"
#include "matrix_keypad.h"

/*
 * General output states.
 */
#define OFF                         0U
#define ON                          1U

/*
 * Fan output.
 */
#define FAN                         RC2
#define FAN_DDR                     TRISC2

/*
 * Buzzer output.
 */
#define BUZZER                      RC1
#define BUZZER_DDR                  TRISC1

/*
 * Door sensing is disabled in this PICSimLab version.
 *
 * RA5 is shared with the fourth seven-segment display selector.
 * Keeping RA5 inactive prevents DISP4 from remaining illuminated.
 *
 * Returning 0 means the microwave logic always considers the
 * door closed.
 */
#define IS_DOOR_OPEN()              (0U)

/*
 * Microwave limits and default timings.
 */
#define MAX_TEMPERATURE_C           180U
#define PREHEAT_TIME_SECONDS        60U
#define QUICK_START_SECONDS         30U
#define BUZZER_TIME_SECONDS         2U

/*
 * Countdown variables maintained by the timer interrupt.
 */
extern volatile unsigned char min;
extern volatile unsigned char sec;

/*
 * Microwave controller functions.
 */
void micro_oven_init(void);
void micro_oven_task(unsigned char key);
void display_power_screen(void);
void display_modes(void);

#endif