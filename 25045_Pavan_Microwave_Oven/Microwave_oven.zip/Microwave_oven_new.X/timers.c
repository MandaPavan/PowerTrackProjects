#include "timers.h"

void init_timer2(void)
{
    /*
     * Fosc = 20 MHz, instruction clock = 5 MHz.
     * Prescaler 1:16, PR2 = 250, postscaler 1:16 gives about 12.85 ms/IRQ.
     * The ISR groups 39 IRQs into ~0.5 s and 78 IRQs into ~1 s.
     */
    TMR2 = 0;
    PR2 = 250;
    T2CON = 0x7B;       /* post 1:16, Timer2 OFF, prescale 1:16 */
    TMR2IF = 0;
    TMR2IE = 1;
    TMR2ON = 1;
}

static unsigned char take_event(volatile unsigned char *event_count)
{
    unsigned char result = 0;
    unsigned char gie_state = GIE;

    GIE = 0;
    if (*event_count > 0U)
    {
        (*event_count)--;
        result = 1;
    }
    GIE = gie_state;

    return result;
}

unsigned char timer_take_half_second(void)
{
    return take_event(&timer_half_second_events);
}

unsigned char timer_take_one_second(void)
{
    return take_event(&timer_one_second_events);
}
