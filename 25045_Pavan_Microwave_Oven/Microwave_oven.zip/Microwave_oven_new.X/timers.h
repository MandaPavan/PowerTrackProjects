#ifndef TIMERS_H
#define TIMERS_H

#include "main.h"

void init_timer2(void);
unsigned char timer_take_half_second(void);
unsigned char timer_take_one_second(void);

extern volatile unsigned char timer_half_second_events;
extern volatile unsigned char timer_one_second_events;

#endif
